package com.example.scheduler;

public class ListViewItem {
    private String text;

    public void setText(String txt){
        this.text = txt;
    }

    public String getText(){
        return text;
    }
}
