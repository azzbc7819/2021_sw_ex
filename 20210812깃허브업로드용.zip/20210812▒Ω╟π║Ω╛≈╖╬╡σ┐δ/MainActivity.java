package com.example.scheduler;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

public class MainActivity extends AppCompatActivity {
    EditText ed;
    Button add, del;
    ListView list;
    MyAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ed = findViewById(R.id.editText);
        add = findViewById(R.id.Addbt);
        del = findViewById(R.id.Deletebt);

        adapter = new MyAdapter();

        list = findViewById(R.id.ListView);
        list.setAdapter(adapter);

        adapter.addItem("첫번째 할 일");
    }
}